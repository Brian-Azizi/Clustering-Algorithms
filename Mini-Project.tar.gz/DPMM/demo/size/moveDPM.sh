#!/bin/bash

k=6
mv dpmMU.out demo/dpmMU$k.out
mv dpmSIGMA.out demo/dpmSIGMA$k.out
mv dpmIDX.out demo/dpmIDX$k.out
mv chainK.out demo/chainK$k.out
mv demo.dat demo/demo$k.dat